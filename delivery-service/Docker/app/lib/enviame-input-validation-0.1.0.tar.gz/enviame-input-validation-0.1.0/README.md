# Nombre Proyecto: Input Validation Python Package

* **Tipo:** Librería
* **Lenguaje:** Python 3

### Descripción

Librería simple para facilitar la validación de datos de entrada de APIs REST en Python.

Internamente utiliza la librería Cerberus para realizar la validación. Sin embargo, Cerberus devuelve los campos inválidos en un formato distinto al formato en el que se debe entregar a nivel de empresa. Esta librería toma la respuesta entregada por Cerberus y la traduce al formato correcto.

La respuesta original de Cerberus tiene el siguiente formato:

```
{

    "age": [
        "required field"
    ],

    "name": [
        "must be of string type"
    ],

    "contact": [

        {
            "dni": [
                "required field"
            ],

            "phone": [
                "must be of integer type"
            ]
        }
    ]
}
```

Esta librería toma esta respuesta y la transforma al nuevo formato, agregando mensajes y códigos de estado:

```
{
    "code": "fail",
    "message": "There was an error in the input data",
    "errors": [
        
        {
            "field": "age",
            "code": "required",
            "message": "Field required"
        },

        {
            "field": "name",
            "code": "incorrect_type",
            "message": "Field must be a string"
        },

        {
            "field": "contact.dni",
            "code": "required",
            "message": "Field required"
        },

        {
            "field": "contact.phone",
            "code": "required",
            "message": "Field must be an integer"
        }
    ]
}
```

Esta librería incluye dos funciones:

- `validate_schema`: Recibe un diccionario y además un esquema de validación, y retorna un posible diccionario ya formateado con los errores, en caso de haber. Ver la documentación de Cerberus para ver el formato que deben tener los esquemas.

- `validate_schema_flask`: Decorador de conveniencia para aplicaciones hechas en Flask. Internamente llama a `validate_schema`.

Ambas funciones se pueden importar de la siguiente manera:

    from enviame.inputvalidation import validate_schema, validate_schema_flask

### Construcción 🛠️

Para construir la librería misma, es debe ejecutar el siguiente comando:

    docker-compose run python-package python -m build

Esto generará las carpetas `build` y `dist` en la carpeta raíz del proyecto si es que aún no existen. Si estas carpetas ya existían, entonces su contenido será reemplazado automáticamente. Tener en cuenta que ambas carpetas están ignoradas en `.gitignore`, así que sus contenidos no serán subidos al repositorio GIT.

Dentro de la carpeta `dist` se generarán los archivos distrubuibles en formato `tar.gz` y `whl`. Se puede usar cualquiera de los dos para importarlo en un proyecto real.

### Instalación 🔧

Para utilizar en un proyecto el paquete generado en el paso anterior, se debe copiar y pegar el archivo `.tar.gz` o el `.whl` en la carpeta del proyecto destino, preferentemente en una carpeta de nombre `lib`, y agregar la dependencia en el archivo `requirements.txt`, reemplazando según corresponda:

    lib/enviame-input-validation-0.1.0.tar.gz

Si el proyecto se encuentra dockerizado, asegurarse además de copiar la carpeta `lib` en el `Dockerfile` para que la librería se instale correctamente en el contenedor:

    COPY lib lib

Al usar `pip install -r requirements.txt`, la librería se instalará junto con el resto de dependencias definidas en el archivo.

### Pruebas ⚙️

Este proyecto no es un servidor HTTP, por lo que no se puede levantar con Docker, pero sí se pueden ejecutar comandos específicos que corren solamente una vez.

En este ejemplo se incluye un test para el caso de uso. Para correrlos, ejecutar el siguiente comando:

    docker-compose run python-package python -m pytest

Se usa `run` en vez de `exec` para levantar un contenedor temporal que sólo existirá durante la ejecución de los tests.

### Despliegue 📦

Si se realizaron modificaciones a una librería, se recomienda editar el número de versión en la línea 3 del archivo `setup.cfg`, siguiendo las convenciones del versionamiento semántico, en donde la versión corresponde a tres números: `X.Y.Z`, con `X` siendo "major", `Y` "minor" y `Z` "patch". Si se hizo un cambio grande incompatible con versiones anteriores, se aumenta `X`; si se agrega una funcionalidad, se aumenta `Y`, y si se hace una corrección pequeña, se aumenta `Z`.

Se está trabajando en poder subir las librerías al Artifact Registry en GCP, para evitar tener que copiar librerías de una carpeta a otra manualmente. Actualmente Artifact Registry se encuentra en beta. Por mientras, los paquetes ya construidos se pueden dejar dentro del mismo repositorio, preferentemente dentro de una carpeta `release`. Así, personas que quieran utilizar esta librería pueden ir directo al repositorio y copiar los archivos encontrados en esta carpeta. La idea es tener todas las versiones, no solamente la última, para mantener un historial.

Es responsabilidad de los mantenedores de la librería mantener actualizada la carpeta `release` con las versiones ya construidas. Para esto se debe construir el paquete usando el comando `python -m build`, y copiar el archivo generado en `dist` a la carpeta `release`. A diferencia de `dict`, la carpeta `release` no está ignorada en el `.gitignore`, así que su contenido será subido al repositorio al hacer `git push`.

### Autores ✒️

* **Autor:** Hans Auzian C., hans.auzian@enviame.io